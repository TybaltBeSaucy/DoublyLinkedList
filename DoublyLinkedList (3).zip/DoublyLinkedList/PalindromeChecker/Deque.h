#include "DoublyLinkedList.h"

template <typename T>
class Deque {
private:
    DoublyLinkedList<T> list;

public:
    void push_front(const T &value) {
        list.push_front(value);
    }

    T pop_front() {
        return list.pop_front();
    }

    T pop_back() {
        return list.pop_back();
    }

    bool is_empty() {
        return list.is_empty();
    }

    int size() {
        return list.size();
    }

    void print_deque() {
        list.print_list();
    }
};