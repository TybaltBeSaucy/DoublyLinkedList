#include <iostream>
#include <cctype>

#include "Deque.h"

using namespace std;

bool isPalindrome(const std::string &str) {
    Deque<char> deque;

    for (char c : str) {
        if (isalpha(c)) {
            deque.push_front(std::tolower(c));
        }
    }

    // Continue checking until the deque is empty or only one character is left
    while (!deque.is_empty() && deque.size() > 1) {
        if (deque.pop_front() != deque.pop_back()) {
            return false; // If the characters don't match, it's not a palindrome
        }
    }

    return true; // If the loop completes, the string is a palindrome
}

int main()
{
    std::string testStrings[] = {"hello", "radar", "racecar", "kayak"};

    for (const auto &str : testStrings)
    {
        std::cout << str << (isPalindrome(str) ? " is a palindrome" : " is NOT a palindrome") << std::endl;
    }

    return 0;
}
