#include "Queue.h"

// Function to generate binary numbers from 1 to n
void generateBinaryNumbers(int n) {
    Queue<std::string> binaryQueue;
    binaryQueue.enqueue("1");

    while (n-- > 0) {
        std::string front = binaryQueue.dequeue();
        std::cout << front << std::endl;

        std::string temp = front;

        binaryQueue.enqueue(temp.append("0"));
        binaryQueue.enqueue(front.append("1"));
    }
}

int main() {
    // Generate binary numbers from 1 to 12
    std::cout << "Binary numbers from 1 to 12:" << std::endl;
    generateBinaryNumbers(12);

    return 0;
}