#include <iostream>
#include <string>
#include <queue>
#include "DoublyLinkedList.h" // Include your DoublyLinkedList class header

// Queue class using DoublyLinkedList as the backing store
template <typename T>
class Queue {
private:
    DoublyLinkedList<T> list;

public:
    void enqueue(T value) {
        list.push_back(value);
    }

    T dequeue() {
        if (list.is_empty()) {
            throw std::logic_error("Queue is empty");
        }
        return list.pop_front();
    }

    bool is_empty() const {
        return list.is_empty();
    }

    int size() const {
        return list.size();
    }
};